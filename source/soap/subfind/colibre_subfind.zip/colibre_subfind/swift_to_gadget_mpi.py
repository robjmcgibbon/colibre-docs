#!/bin/env python
#
# Convert a single file Swift snapshot to one or more
# Gadget HDF5 snapshot files.
#
# Here we assume the output units should be
#
# Positions:  comoving Mpc/h
# Velocities: comoving velocity*sqrt(a), in km/sec
# Masses:     1e10 Msolar/h
#

import os
import sys
import argparse
import numpy as np
import h5py

from mpi4py import MPI
comm = MPI.COMM_WORLD
comm_rank = comm.Get_rank()
comm_size = comm.Get_size()

def convert_coordinates(data, cgs_conversion, a_exponent, h_exponent, a, h, constants):
    """Return coordinates in comoving Mpc/h given Swift coordinates"""
    conversion = cgs_conversion / (1.0e6*constants["parsec"]) * (h**(h_exponent+1)) * (a**(a_exponent-1))
    return (data * conversion).astype(data.dtype)

def convert_velocities(data, cgs_conversion, a_exponent, h_exponent, a, h, constants):
    """Return velocity as dx/dt*sqrt(a) in km/s given Swift velocities"""
    conversion = cgs_conversion / 1.0e5 * (h**h_exponent) * (a**(a_exponent-0.5))
    return (data * conversion).astype(data.dtype)

def convert_particleids(data, cgs_conversion, a_exponent, h_exponent, a, h, constants):
    """No conversion is needed for particle IDs"""
    return data

def convert_masses(data, cgs_conversion, a_exponent, h_exponent, a, h, constants):
    """Return masses in 1e10Msolar/h given Swift masses"""
    conversion = cgs_conversion / (1e10*constants["solar_mass"]) * (h**(h_exponent+1)) * (a**a_exponent)
    return (data * conversion).astype(data.dtype)

def convert_smoothing_lengths(data, cgs_conversion, a_exponent, h_exponent, a, h, constants):
    """Return coordinates in comoving Mpc/h given Swift coordinates"""
    conversion = cgs_conversion / (1.0e6*constants["parsec"]) * (h**(h_exponent+1)) * (a**(a_exponent-1))
    return (data * conversion).astype(data.dtype)

def convert_internal_energy(data, cgs_conversion, a_exponent, h_exponent, a, h, constants):
    """Return internal energy in km^2/s^2"""
    conversion = cgs_conversion * (h**h_exponent) * (a**a_exponent) # To (cm/s)^2
    conversion /= 1.0e10                                            # To (km/s)^2
    return (data * conversion).astype(data.dtype)

def convert_density(data, cgs_conversion, a_exponent, h_exponent, a, h, constants):
    """Return density in 10^10 (Msun/h)/(Mpc/h)^3 comoving """
    conversion = cgs_conversion * (h**h_exponent) * (a**a_exponent) # to g per physical cm^3
    conversion /= (1e10*constants["solar_mass"])                    # to 1e10Msolar per physical cm^3
    conversion *= (1.0e6*constants["parsec"])**3.                   # to 1e10Msolar per physical Mpc^3
    conversion *= (a**3)                                            # to 1e10Msolar per comoving Mpc^3
    conversion /= (h**3)                                            # to 1e10Msolar per comoving (Mpc/h)^3
    conversion *= h                                                 # to 1e10Msolar/h per comoving (Mpc/h)^3
    return (data * conversion).astype(data.dtype)

#
# This lists the quantities we know how to convert to Gadget units.
# Entries are of the form
#
# swift_dataset_name : (gadget_dataset_name, conversion_function)
#
conversion_functions = {
    "Coordinates"     : ("Coordinates",     convert_coordinates),
    "Velocities"      : ("Velocities",      convert_velocities),
    "ParticleIDs"     : ("ParticleIDs",     convert_particleids),
    "Masses"          : ("Masses",          convert_masses),
    "SmoothingLengths": ("SmoothingLength", convert_smoothing_lengths),
    "DynamicalMasses" : ("Masses",          convert_masses),
    "InternalEnergies": ("InternalEnergy",  convert_internal_energy),
    "Densities"       : ("Density",         convert_density),    
}


def convert_snapshot(input_filename, output_basename, num_output_files):
    
    # Open the Swift snapshot
    swift_snap = h5py.File(input_filename, "r")

    # Read physical constants in CGS units
    constants = {}
    for name in swift_snap["PhysicalConstants/CGS"].attrs:
        constants[name] = swift_snap["PhysicalConstants/CGS"].attrs[name]

    # Get swift length unit info (used to convert box size)
    swift_length_unit_cgs = swift_snap["Units"].attrs["Unit length in cgs (U_L)"]
    swift_parsec_cgs = swift_snap["PhysicalConstants/CGS"].attrs["parsec"]
    swift_megaparsec = swift_length_unit_cgs / (1.0e6*swift_parsec_cgs)

    # Get expansion factor and hubble parameter
    a = swift_snap["Cosmology"].attrs["Scale-factor"]
    h = swift_snap["Cosmology"].attrs["h"]
    
    # Find total number of particles of each type
    npart_total_lw  = swift_snap["Header"].attrs["NumPart_Total"].astype(np.int64)
    npart_total_hw  = swift_snap["Header"].attrs["NumPart_Total_HighWord"].astype(np.int64)
    npart_total = npart_total_lw + (npart_total_hw << 32)
    ntypes = npart_total.shape[0]

    # Limit to 6 particle types (i.e. discard neutrinos)
    ntypes = 6
    npart_total = npart_total[:ntypes]

    # Share particles equally between output files
    npart_file = np.zeros((num_output_files,ntypes), dtype=np.int64)
    for itype in range(ntypes):
        npart_file[:,itype] = npart_total[itype] // num_output_files
        npart_file[:npart_total[itype] % num_output_files, itype] += 1
        assert np.sum(npart_file[:,itype]) == np.sum(npart_total[itype])
        
    # Find offset in the input file to the first particle to go
    # in each output file
    offset_file = np.zeros_like(npart_file)
    for itype in range(ntypes):
        offset_file[:, itype] = (np.cumsum(npart_file[:, itype]) - 
                                 npart_file[:, itype])

    # Loop over output files
    for ifile in range(num_output_files):

        if ifile % comm_size == comm_rank:

            # Create the next output file
            output_filename = output_basename+(".%d.hdf5" % ifile)
            os.makedirs(os.path.dirname(output_filename), exist_ok=True)
            
            gadget_snap = h5py.File(output_filename, "w")

            # Write the header
            header = gadget_snap.create_group("Header")
            header.attrs["NumPart_ThisFile"] = npart_file[ifile, :].astype(np.int32)
            # Gadget-4 reads NumPart_Total as full 64-bit values from HDF5
            # snapshots and ignores NumPart_Total_HighWord
            header.attrs["NumPart_Total"] = npart_total.astype(np.uint64)
            header.attrs["NumFilesPerSnapshot"] = num_output_files
            header.attrs["MassTable"] = np.zeros(ntypes, dtype=np.float64)
            header.attrs["Omega0"] = swift_snap["Cosmology"].attrs["Omega_m"]
            header.attrs["OmegaLambda"] = swift_snap["Cosmology"].attrs["Omega_lambda"]
            header.attrs["HubbleParam"] = h
            header.attrs["Redshift"] = swift_snap["Cosmology"].attrs["Redshift"]
            header.attrs["Time"] = a
            # We don't know the values of these flags - just set to zero for now
            for name in ("Flag_Cooling","Flag_DoublePrecision", "Flag_Feedback", "Flag_IC_Info",
                         "Flag_Metals", "Flag_Sfr", "Flag_StellarAge"):
                header.attrs[name] = np.int32(0)

            # Box size needs to be converted into Mpc/h, and made into a scalar
            # (it's a vector in swift)
            boxsize = swift_snap["Header"].attrs["BoxSize"]
            if np.all(boxsize==boxsize[0]):
                boxsize = boxsize[0]
            else:
                raise Exception("Can only handle cubic boxes!")
            header.attrs["BoxSize"] = boxsize/swift_megaparsec*h

            # Loop over particle types
            for itype in range(ntypes):
                if npart_file[ifile, itype] > 0:

                    swift_group = swift_snap["PartType%d" % itype]
                    gadget_group = gadget_snap.create_group("PartType%d" % itype)

                    offset = offset_file[ifile, itype]
                    num    = npart_file[ifile, itype]

                    # Loop over quantities to copy over
                    for name in conversion_functions:
                        gadget_name, conversion_function = conversion_functions[name]
                        if name == "InternalEnergies" and itype == 0 and name not in swift_group:
                            raise KeyError("PartType0/InternalEnergies not found in snapshot")
                        if name in swift_group:

                            print("Writing file %d, type %d, property %s" % (ifile, itype, name))

                            # Read the data
                            swift_data = swift_group[name][offset:offset+num,...]
                            # Get metadata
                            cgs_conversion = swift_group[name].attrs["Conversion factor to CGS (not including cosmological corrections)"]
                            a_exponent = swift_group[name].attrs["a-scale exponent"]
                            h_exponent = swift_group[name].attrs["h-scale exponent"]
                            # Convert to Gadget units
                            gadget_data = conversion_function(swift_data, cgs_conversion,
                                                              a_exponent, h_exponent, a, h,
                                                              constants)
                            # Write to the output file, if necessary
                            if gadget_name == "Masses" and np.amin(gadget_data) == np.amax(gadget_data):
                                # No need to write out masses if they're all the same - can update header instead.
                                masstable = gadget_snap["Header"].attrs["MassTable"]
                                masstable[itype] = gadget_data[0]
                                gadget_snap["Header"].attrs["MassTable"] = masstable
                            else:
                                gadget_group[gadget_name] = gadget_data



if __name__ == "__main__":

    from virgo.mpi.util import MPIArgumentParser

    # Get command line argments
    parser = MPIArgumentParser(comm, description="Convert Swift snapshot to Gadget HDF5")
    parser.add_argument("input_filename",
                        help="Name of the input Swift snapshot file")
    parser.add_argument("output_basename",
                        help="Base name for the output Gadget file(s)")
    parser.add_argument("num_output_files", type=int,
                        help="Number of output files to generate")    
    args = parser.parse_args()
 
    # Run the code
    convert_snapshot(args.input_filename, args.output_basename,
                     args.num_output_files)

    comm.barrier()
    if comm_rank == 0:
        print("Done.")
