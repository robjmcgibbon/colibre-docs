# Gadget-4 compile-time configuration for running FOF+SUBFIND as
# post-processing on COLIBRE snapshots converted to Gadget format.
#
# Options copied from the Config group of the reference catalogues in
# /cosma8/data/dp004/dc-mcgi1/COLIBRE/Subfind (Victor's run).

# Gravity and box
PERIODIC
SELFGRAVITY
PMGRID=1024
TREE_NUM_BEFORE_NODESPLIT=16
NSOFTCLASSES=1

# Group finding
FOF
FOF_PRIMARY_LINK_TYPES=2
FOF_SECONDARY_LINK_TYPES=49
FOF_GROUP_MIN_LEN=32
SUBFIND

# Data representation
GADGET2_HEADER
IDS_64BIT
POSITIONS_IN_64BIT

# MPI shared-memory handling
NUMBER_OF_MPI_LISTENERS_PER_NODE=2
OLDSTYLE_SHARED_MEMORY_ALLOCATION
