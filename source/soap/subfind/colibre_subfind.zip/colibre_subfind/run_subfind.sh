#!/bin/bash -l
#
# Run Gadget-4 FOF+SUBFIND on a COLIBRE (SWIFT) snapshot.
# Requires gadget4/Gadget4 to have been compiled already (see compile.sh).
#
# Usage:
#
#   sbatch [sbatch options] run_subfind.sh <RUN> [MODEL]
#
#   RUN    run name under /cosma8/data/dp004/colibre/Runs,
#          e.g. L0025N0376 or L0200N1504
#   MODEL  model subdirectory (default: Thermal)
#
# The snapshot number is the array task ID, or 127 (z=0) if not an array
# job. Only snapshots 84-127 (z <= 1.5) are supported, see below. The job
# size is set on the command line; everything in the script adapts to it.
# Examples:
#
#   sbatch run_subfind.sh L0025N0376                    # snap 127, 1 node
#   sbatch --array=84-127 run_subfind.sh L0025N0376     # one job per snap
#   sbatch --array=92 --nodes=20 -t 10:00:00 run_subfind.sh L0200N1504
#
# On cosma8 there is no need to pass --ntasks (--ntasks-per-node is set below)
#
# Sizing guide:
#
#   Memory: ~425 B/particle measured (L0025N0752, snap 127), must fit in
#   ntasks * 7 GB. Run time is dominated NOT by total particle count but by
#   the unbinding of the largest FOF groups
#
#   Run         Particles    Largest group    Num nodes  Wallclock time
#   L0025N0376  2.7e8        ~1.2e7           1          ~1h
#   L0025N0752  2.1e9        1.0e8            4          ~10 h
#   L0200N1504  1.7e10       7.5e7            20         ~5 h
#
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=128
#SBATCH --cpus-per-task=1
#SBATCH -o ./logs/%x.%j.out
#SBATCH -J subfind
#SBATCH -p cosma8
#SBATCH -A dp004
#SBATCH --exclusive
#SBATCH -t 4:00:00

set -e

module purge
module load cosma
module load python/3.12.4
module load gnu_comp/14.1.0
module load openmpi/5.0.3
module load parallel_hdf5/1.12.3
module load gsl/2.8
module load fftw/3.3.10
source /cosma/apps/dp004/dc-mcgi1/python_env/default/bin/activate


# --- Command line arguments --------------------------------------------

if [ -z "$1" ]; then
    echo "Usage: sbatch [sbatch options] run_subfind.sh <RUN> [MODEL]"
    echo "e.g.:  sbatch run_subfind.sh L0025N0376 Thermal"
    exit 1
fi
RUN=$1
MODEL=${2:-Thermal}

SUBFIND_DIR=/cosma/home/dp004/dc-mcgi1/COLIBRE/subfind
SIM_DIR=/cosma8/data/dp004/colibre/Runs/${RUN}/${MODEL}
OUTPUT_DIR=/snap8/scratch/dp004/dc-mcgi1/COLIBRE/subfind/${RUN}/${MODEL}
MAXMEMSIZE=7000           # MB per rank; ntasks/nodes * MAXMEMSIZE must fit in node RAM

# Snapshot number: array task ID if this is an array job, else 127
SNAP=${SLURM_ARRAY_TASK_ID:-127}

# Only the *physical* softening is read from the snapshot (see below), which
# is only valid where COLIBRE is in the fixed-physical-softening regime,
# i.e. z < 1.57. Earlier snapshots would need the comoving softening instead.
if [ ${SNAP} -lt 84 ]; then
    echo "ERROR: snapshot ${SNAP} < 84 (z > 1.5): the script reads only the"
    echo "physical softening, which is not valid at these redshifts."
    exit 1
fi

SNAP4=$(printf "%04d" ${SNAP})   # SWIFT names use 4 digits
SNAP3=$(printf "%03d" ${SNAP})   # Gadget-4 names use 3 digits (snapdir_%03d)
SWIFT_SNAPSHOT=${SIM_DIR}/snapshots/colibre_${SNAP4}/colibre_${SNAP4}.hdf5
if [ ! -f ${SWIFT_SNAPSHOT} ]; then
    echo "ERROR: snapshot not found: ${SWIFT_SNAPSHOT}"
    exit 1
fi

# --- Read run parameters from the SWIFT snapshot ------------------------

# BoxSize in Mpc/h and the softening in Mpc/h. Gadget-4 applies
# eps = min(SofteningComoving * a, SofteningMaxPhys), so setting
# SofteningComoving = SofteningMaxPhys / a guarantees the physical value
# is the one in effect at this snapshot's redshift.

VALUES=$(python3 - "${SWIFT_SNAPSHOT}" <<'PYEOF'
import sys
import numpy as np
import h5py

def scalar(x):
    return float(np.ravel(x)[0])

with h5py.File(sys.argv[1], "r") as snap:
    h = scalar(snap["Cosmology"].attrs["h"])
    a = scalar(snap["Cosmology"].attrs["Scale-factor"])
    z = scalar(snap["Cosmology"].attrs["Redshift"])
    length_cgs = scalar(snap["Units"].attrs["Unit length in cgs (U_L)"])
    mpc_cgs = 1.0e6 * scalar(snap["PhysicalConstants/CGS"].attrs["parsec"])
    to_mpc_h = length_cgs / mpc_cgs * h

    boxsize = snap["Header"].attrs["BoxSize"]
    if not np.all(boxsize == boxsize[0]):
        sys.exit("Can only handle cubic boxes")

    params = snap["Parameters"].attrs
    eps_dm = float(params["Gravity:max_physical_DM_softening"].decode())
    eps_baryon = float(params["Gravity:max_physical_baryon_softening"].decode())
    if eps_dm != eps_baryon:
        sys.exit("DM and baryon softenings differ, but NSOFTCLASSES=1")

if z > 1.55:
    sys.exit(f"z = {z} is outside the fixed-physical-softening regime")

soft_maxphys = eps_dm * to_mpc_h
soft_comoving = soft_maxphys / a
print(f"{scalar(boxsize) * to_mpc_h:.10g} {soft_comoving:.6g} {soft_maxphys:.6g}")
PYEOF
)
read BOXSIZE SOFT_COMOVING SOFT_MAXPHYS <<< "${VALUES}"
echo "Run ${RUN}/${MODEL} snapshot ${SNAP}:"
echo "  BoxSize = ${BOXSIZE} Mpc/h"
echo "  SofteningMaxPhys = ${SOFT_MAXPHYS} Mpc/h (comoving entry ${SOFT_COMOVING})"


# --- Number of snapshot files ------------------------------------------

# Gadget-4 loses 2 ranks per node to shared-memory listeners
# (NUMBER_OF_MPI_LISTENERS_PER_NODE=2 in Config.sh) and silently reduces
# NumFilesPerSnapshot to the writer count, orphaning already-written files
# when it rewrites the snapshot in group order. So converter output count
# and NumFilesPerSnapshot must both equal min(ntasks - 2*nodes, 64).

NFILES=$(( SLURM_NTASKS - 2*SLURM_JOB_NUM_NODES ))
if [ ${NFILES} -gt 64 ]; then NFILES=64; fi
echo "Ranks: ${SLURM_NTASKS} on ${SLURM_JOB_NUM_NODES} node(s) -> ${NFILES} snapshot files"


# --- Step 1: convert SWIFT snapshot to Gadget format -------------------

# Remove any previous conversions
SNAPDIR=${OUTPUT_DIR}/snapdir_${SNAP3}
if compgen -G "${SNAPDIR}/snapshot_${SNAP3}.*.hdf5" > /dev/null; then
    echo "Removing previous conversion in ${SNAPDIR}"
    rm ${SNAPDIR}/snapshot_${SNAP3}.*.hdf5
fi

mpirun -np ${SLURM_NTASKS} python ${SUBFIND_DIR}/swift_to_gadget_mpi.py \
    ${SWIFT_SNAPSHOT} ${SNAPDIR}/snapshot_${SNAP3} ${NFILES}

# --- Step 2: write Gadget-4 parameter file -----------------------------

# Based on the reference run's parameters-usedvalues (see README.md).
# Omega0 = 1 - OmegaLambda: includes neutrino+radiation, not just Omega_m.

mkdir -p ${OUTPUT_DIR}
echo "1.0" > ${OUTPUT_DIR}/outputs.txt
PARAM=${OUTPUT_DIR}/param_snap${SNAP}.txt
cat > ${PARAM} <<EOF
InitCondFile                                      dummy_variable
OutputDir                                         ${OUTPUT_DIR}/
SnapshotFileBase                                  snapshot
OutputListFilename                                ${OUTPUT_DIR}/outputs.txt
ICFormat                                          3
SnapFormat                                        3
TimeLimitCPU                                      43200
CpuTimeBetRestartFile                             18000
MaxMemSize                                        ${MAXMEMSIZE}
TimeBegin                                         0.015625
TimeMax                                           1
ComovingIntegrationOn                             1
Omega0                                            0.306078
OmegaLambda                                       0.693922
OmegaBaryon                                       0.0486
HubbleParam                                       0.681
BoxSize                                           ${BOXSIZE}
Hubble                                            100
OutputListOn                                      1
TimeBetSnapshot                                   0
TimeOfFirstSnapshot                               0
TimeBetStatistics                                 0.01
NumFilesPerSnapshot                               ${NFILES}
MaxFilesWithConcurrentIO                          32
ErrTolIntAccuracy                                 0.012
CourantFac                                        0.3
MaxSizeTimestep                                   0.01
MinSizeTimestep                                   0
TypeOfOpeningCriterion                            1
ErrTolTheta                                       0.4
ErrTolThetaMax                                    0.8
ErrTolForceAcc                                    0.0025
TopNodeFactor                                     5
ActivePartFracForNewDomainDecomp                  0.01
DesNumNgb                                         64
MaxNumNgbDeviation                                8
UnitLength_in_cm                                  3.08568e+24
UnitMass_in_g                                     1.989e+43
UnitVelocity_in_cm_per_s                          100000
GravityConstantInternal                           0
SofteningComovingClass0                           ${SOFT_COMOVING}
SofteningMaxPhysClass0                            ${SOFT_MAXPHYS}
SofteningClassOfPartType0                         0
SofteningClassOfPartType1                         0
SofteningClassOfPartType2                         0
SofteningClassOfPartType3                         0
SofteningClassOfPartType4                         0
SofteningClassOfPartType5                         0
DesLinkNgb                                        20
ArtBulkViscConst                                  1
MinEgySpec                                        0
InitGasTemp                                       0
EOF

# --- Step 3: run FOF+SUBFIND (RestartFlag 3) ---------------------------

mpirun -np ${SLURM_NTASKS} ${SUBFIND_DIR}/gadget4/Gadget4 ${PARAM} 3 ${SNAP}

echo "Job complete!"
