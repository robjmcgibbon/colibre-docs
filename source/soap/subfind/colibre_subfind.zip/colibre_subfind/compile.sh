#!/bin/bash
#
# Compile Gadget-4 (FOF+SUBFIND post-processing config) on COSMA8.
#
# Works from a clean clone of the Gadget-4 source. Steps:
#
#   1. Clone the code (if not already present):
#        git clone http://gitlab.mpcdf.mpg.de/vrs/gadget4
#   2. Run this script:
#        ./compile.sh
#
# The script loads the modules, copies ./Config.sh (the compile-time
# options, kept at the top level so they survive a re-clone) into the
# source directory, selects the "Generic-gcc" build target, and runs make.
# The executable ends up at gadget4/Gadget4.

set -e

module purge
module load cosma
module load python/3.12.4
module load gnu_comp/14.1.0
module load openmpi/5.0.3
module load parallel_hdf5/1.12.3
module load gsl/2.8
module load fftw/3.3.10

if [ ! -d gadget4/src ]; then
    echo "ERROR: gadget4 source not found. Clone it first with:"
    echo "  git clone http://gitlab.mpcdf.mpg.de/vrs/gadget4"
    exit 1
fi

# Compile-time options
cp Config.sh gadget4/Config.sh

# Build target: generic gcc (mpicxx). No Makefile edits are needed because
# the modules above put all headers/libraries on CPATH/LIBRARY_PATH.
# (A gadget4/Makefile.systype file would override this variable if present.)
export SYSTYPE="Generic-gcc"

cd gadget4
make -j 8

echo
echo "Build complete: $(pwd)/Gadget4"

