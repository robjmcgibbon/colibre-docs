# Running Gadget-4 SUBFIND on COLIBRE snapshots

Pipeline for producing FOF+SUBFIND halo catalogues from COLIBRE (SWIFT)
snapshots. Two steps:

1. **Convert** the SWIFT snapshot to Gadget HDF5 format
2. **Run Gadget-4 as post-processing** on the converted snapshot

## Files

| File | Purpose |
|------|---------|
| `compile.sh` | Loads modules and builds `gadget4/Gadget4` (clone repo first, see script header) |
| `Config.sh` | Gadget-4 compile-time options; copied into `gadget4/` by `compile.sh` |
| `swift_to_gadget_mpi.py` | MPI SWIFT→Gadget snapshot converter |
| `run_subfind.sh` | sbatch script: conversion + subfind in one job; works for any run, e.g. `sbatch --nodes=16 run_subfind.sh L0200N1504 Thermal` (see script header) |

## MPI ranks vs number of snapshot files

`Config.sh` sets `NUMBER_OF_MPI_LISTENERS_PER_NODE=2`, so each node
donates 2 ranks as shared-memory listeners. With `N` total ranks on `M`
nodes, only `N - 2*M` ranks do compute/IO. Gadget-4 silently reduces
`NumFilesPerSnapshot` to that writer count if it is larger. Therefore:

```
num_output_files (converter) = NumFilesPerSnapshot (param file) = min(N - 2*M, 64)
```

The `min(..., 64)` cap just avoids very many small files at high rank
counts. `run_subfind.sh` applies this rule automatically from the SLURM config.

## Gadget-4 rewrites the snapshot in group order

After computing the catalogue, Gadget-4 rewrites the input snapshot so
that particles are stored in group+subhalo order (convenient for membership
lookup: each group is a contiguous slice). As a result `snapdir_XXX` no longer holds
the conversion-ordered snapshot afterwards.
Re-run the converter if the original ordering is needed.

## Parameter file notes

- Cosmology: `Omega0 = 1 - OmegaLambda = 0.306078`, i.e. it includes the
  neutrino and radiation contributions from the SWIFT `Cosmology` group
  (`Omega_m + Omega_nu_0 + Omega_r`), NOT SWIFT's `Omega_m` alone.
- `BoxSize` (`L * h`, e.g. 25 cMpc * 0.681 = 17.025 Mpc/h) and the softening
  are read from the SWIFT snapshot by `run_subfind.sh` (`Header/BoxSize` and
  the `Parameters` group attributes), so no per-run editing is needed.
- Only the *physical* softening (`Gravity:max_physical_DM_softening * h`) is
  used. This is only valid in COLIBRE's fixed-physical-softening regime, z < 1.57,
  so the script refuses snapshots < 84 (z = 1.5 at snap 84).
- The same compile-time `Config.sh` (incl. `PMGRID=1024`) is used for all box
  sizes.
